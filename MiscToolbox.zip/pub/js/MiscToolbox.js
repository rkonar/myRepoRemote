function hidecloumn(columnclass,table_header_class){
		
		document.getElementById("show_all"+table_header_class).style.display="";
		var class_details = document.getElementById("hide_class").value;
		if(class_details=='')
		{
			class_details = columnclass;
		}
		else{
			class_details = class_details+','+columnclass;
		}
		
		document.getElementById("hide_class").value = class_details;
		
		var list = document.getElementsByClassName(columnclass);
			for (var i = 0; i < list.length; i++) {
				list[i].style.display="none";
			}
	}
	
function showallhidden(table_header_class){
	
		var class_details = document.getElementById("hide_class").value;
		
		class_details = class_details.split(",");
		
		for(x=0;x < class_details.length; x++ )
		{
			var list = document.getElementsByClassName(class_details[x]);
			for (var i = 0; i < list.length; i++) {
				list[i].style.display="";
			}
			
			
		}
		
		
		document.getElementById("hide_class").value ='';
		document.getElementById("show_all"+table_header_class).style.display="none";
}

function popupFormView(table_header_id,rowid)
	{
		//document.getElementById("convert_html").innerHTML='';
		var rowHTML = document.getElementById(rowid).innerHTML;
		
		
		rowHTML = rowHTML.replace(/class="class[0-9]"/g, "");
		rowHTML = rowHTML.replace(/" style="display: none/g, "");
		rowHTML = rowHTML.replace(/style="display: none;"/g, "");
		
		rowHTML =rowHTML.split("</td>");
		
		var headerHTML = document.getElementById(table_header_id).innerHTML;
		
		headerHTML = headerHTML.replace(/class="class[0-9]"/g, "");
		headerHTML = headerHTML.replace(/class=/g, "");
		headerHTML = headerHTML.replace(/class=/g, "");
		headerHTML = headerHTML.replace(/sorttable_sorted_reverse/g, "");
		headerHTML = headerHTML.replace(/class[0-9]/g, "");
		
		headerHTML = headerHTML.replace(/ondblclick="javascript:hidecloumn/g, "");
		
		headerHTML = headerHTML.replace(/[()';"]/g, "");
		headerHTML = headerHTML.replace(/">/g, ""); 
		headerHTML = headerHTML.replace(/<span id="sorttable_sortrevind">/g, "");
		headerHTML = headerHTML.replace(/<span id="sorttable_sortrevind/g, "");
		headerHTML = headerHTML.replace(/<span id="sorttable_sortrevind/g, "");
		headerHTML = headerHTML.replace(/▴/g, "");
		headerHTML = headerHTML.replace(/<[[/]span>/g, "");
		headerHTML = headerHTML.replace(/" style="display: none/g, "");
		headerHTML = headerHTML.replace(/style="display: none;"/g, "");
		headerHTML = headerHTML.replace(/style=display: none/g, "");
		headerHTML = headerHTML.split("</th>");
		
			
		var htmlPUT="";
		for(i=1;i<headerHTML.length;i++)
		{
			if(i%2==1)
			{
				htmlPUT=htmlPUT+'<tr>';
			}
				htmlPUT=htmlPUT+headerHTML[i]+'</th>'+rowHTML[i]+'</td>';


			if(i%2==0)
			{
				htmlPUT=htmlPUT+'</tr>';
			}
		}
				
		/* document.getElementById("convert_html").innerHTML=htmlPUT;
		alert(htmlPUT);
		return false; */
		
		
		var html = "<html><head><style type='text/css'>";
		html = html + " .tftable {font-size:12px;color:#333333;width:100%;border-width: 1px;border-color: #729ea5;border-collapse: collapse;}"
		html = html + " .tftable th {font-size:12px;background-color:#acc8cc;border-width: 1px;padding: 8px;border-style: solid;border-color: #729ea5;text-align:left;}";
		html = html + " .tftable tr {background-color:#d4e3e5;}";
		html = html + " .tftable td {font-size:12px;border-width: 1px;padding: 8px;border-style: solid;border-color: #729ea5;}";
		html = html + " .tftable tr:hover {background-color:#ffffff;}";
		html = html + " </style></head><body>";
		html = html + " <table class='tftable' style='margin-left:0px' border='0' id='convert_html'>";
		html = html + htmlPUT;
		html = html + "</table></body></html>";
		
		
		var x=window.open("","","","menubar=1,resizable=1,width=500,height=350");
		x.document.open();
		x.document.write(html);
		
		return false;
		
	}
	
	function count_delimiter() {
	document.getElementById("queryListCount").innerHTML='';
	var queryList = document.getElementById("queryList").value;
	var delimiter = document.getElementById("delimiter").value;
	
	if(delimiter=='newline')
		delimiter='\n';
	
	var count = queryList.split(delimiter);
	
	document.getElementById("queryListCount").innerHTML='Count Of Query List is :: '+count.length;
	
	
}