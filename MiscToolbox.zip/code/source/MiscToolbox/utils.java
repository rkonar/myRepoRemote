package MiscToolbox;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import com.wm.util.coder.*;
import com.wm.app.b2b.server.*;
import com.wm.app.b2b.client.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Authenticator;
import java.net.PasswordAuthentication;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import com.wm.data.IData;
import com.wm.data.IDataCursor;
import com.wm.data.IDataUtil;
import java.util.StringTokenizer;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import com.wm.app.b2b.server.ns.NSDependencyManager;
import com.wm.app.b2b.server.ns.Namespace;
import com.wm.app.b2b.server.InvokeState;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
import com.wm.lang.ns.DependencyManager;
import com.wm.lang.ns.NSNode;
import java.net.HttpURLConnection;
import java.io.InputStream;
// --- <<IS-END-IMPORTS>> ---

public final class utils

{
	// ---( internal utility methods )---

	final static utils _instance = new utils();

	static utils _newInstance() { return new utils(); }

	static utils _cast(Object o) { return (utils)o; }

	// ---( server methods )---




	public static final void compareDocuments (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(compareDocuments)>> ---
		// @sigtype java 3.5
		// [i] record:0:required firstDoc
		// [i] record:0:required secondDoc
		// [i] field:0:required firstQualifier
		// [i] field:0:required secondQualifier
		// [o] record:0:required resultDoc
		IDataCursor pipelineCursor = pipeline.getCursor();
		IData	firstDoc = IDataUtil.getIData( pipelineCursor, "firstDoc" );
		IData	secondDoc = IDataUtil.getIData( pipelineCursor, "secondDoc" );
		String firstQualifier = IDataUtil.getString(pipelineCursor, "firstQualifier");
		String secondQualifier = IDataUtil.getString(pipelineCursor, "secondQualifier");
		pipelineCursor.destroy();       
		
		IData resultDoc = IDataFactory.create();
		
		if (firstDoc == null)
		{
			IDataUtil.copy(secondDoc,resultDoc);
			compareTwoIData(resultDoc,secondDoc,null,secondQualifier,firstQualifier,"");      
		}
		else if (secondDoc == null)
		{
			IDataUtil.copy(firstDoc,resultDoc);
			compareTwoIData(resultDoc,firstDoc,null,firstQualifier,secondQualifier,"");
		}
		else if ((firstDoc == null) && (secondDoc == null))
		{
			resultDoc = null;	
		}
		else
		{
			IDataUtil.copy(firstDoc,resultDoc);
			IDataUtil.merge(secondDoc,resultDoc);
			compareTwoIData(resultDoc,firstDoc,secondDoc,firstQualifier,secondQualifier,"");
		}
		
		//-----------------------------------------------------------------------
		IDataCursor pipelineCursorOut = pipeline.getCursor();
		IDataUtil.put(pipelineCursorOut, "resultDoc", resultDoc);
		pipelineCursorOut.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void diffStringList (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(diffStringList)>> ---
		// @sigtype java 3.5
		// [i] field:1:required firstList
		// [i] field:1:required secondList
		// [o] field:1:required diffList
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		String[] firstArray = IDataUtil.getStringArray( pipelineCursor, "firstList" );
		String[] secondArray = IDataUtil.getStringArray( pipelineCursor, "secondList" );
		pipelineCursor.destroy();
		List firstList = new ArrayList(Arrays.asList(firstArray));
		List secondList = new ArrayList(Arrays.asList(secondArray));
		firstList.removeAll(secondList);
		String[] array = (String[])firstList.toArray(new String[firstList.size()]);
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "diffList", array );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void extractDataFromEDIX12String (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(extractDataFromEDIX12String)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:optional ediString
		// [i] field:0:required segmentName
		// [i] field:0:optional fieldQualifier
		// [i] field:0:optional subfieldQualifier
		// [i] field:0:optional fieldPosition
		// [i] field:0:optional subfieldPosition
		// [i] field:0:optional returnRecord
		// [o] field:0:required success
		// [o] field:0:optional errorMessage
		// [o] field:1:required result
		// [o] field:0:required resultCount
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		String	ediString = IDataUtil.getString( pipelineCursor, "ediString" );
		String	segmentName = IDataUtil.getString( pipelineCursor, "segmentName" );
		String	fieldQualifier = IDataUtil.getString( pipelineCursor, "fieldQualifier" );
		String	subfieldQualifier = IDataUtil.getString( pipelineCursor, "subfieldQualifier" );
		String	fieldPosition = IDataUtil.getString( pipelineCursor, "fieldPosition" );
		String	subfieldPosition = IDataUtil.getString( pipelineCursor, "subfieldPosition" );
		String	returnRecord = IDataUtil.getString( pipelineCursor, "returnRecord" );
		pipelineCursor.destroy();

		//Define Output variables
		String success = null;
		String errorMessage = null;
		String[] result = null;
		
		ArrayList<String> resultList = new ArrayList<String>();

		StringTokenizer segmentTokenizer = null;
		String segmentString = null;
		
		List<String> segmentList = new ArrayList<String>();	
		
		List<String> fieldList = new ArrayList<String>();
		List<String> fieldNextValueList = new ArrayList<String>();
		
		List<String> subFieldList = new ArrayList<String>();		
		List<String> subFieldNextValueList = new ArrayList<String>();
		String subFieldValue = null;

		String delimiterSegment = null;
		String delimiterField = null;
		String delimiterSubField = null;

		String debugVar = null;
				
		final String RETURNRECORD_FLAG = "Y";
		
		//below positions are based on zero based indexing
		final int FIELDDELIMITER_POSITION_IN_ISASEGMENT=103;
		final int SUBFIELDDELIMITER_POSITION_IN_ISASEGMENT=104;
		final int SEGMENTDELIMITER_POSITION_IN_ISASEGMENT=105;
		final int ISASEGMENT_LENGTH=106;

		delimiterField = String.valueOf(ediString.charAt(FIELDDELIMITER_POSITION_IN_ISASEGMENT));
		delimiterSubField = String.valueOf(ediString.charAt(SUBFIELDDELIMITER_POSITION_IN_ISASEGMENT));
		delimiterSegment = String.valueOf(ediString.charAt(SEGMENTDELIMITER_POSITION_IN_ISASEGMENT));


		try {
			
			char switchVar = ' ';
			if (returnRecord != null && RETURNRECORD_FLAG.equals(returnRecord)) 
			{
				switchVar = 'S'; // Full Segment
			} else if (fieldQualifier != null && !"".equals(fieldQualifier)) 
			{
				switchVar = 'Q'; // Qualifier based
			} else if (fieldPosition != null && !"".equals(fieldPosition)) 
			{ 
				switchVar = 'P'; // Field Position based
			}
			

			segmentTokenizer = new StringTokenizer(ediString, delimiterSegment);
			while (segmentTokenizer.hasMoreElements()) {
				segmentString = segmentTokenizer.nextToken();
				if (segmentString.startsWith(segmentName + delimiterField)) {
					segmentList.add(segmentString);
				}
			}
			
			success = "0";
			errorMessage = null;
			
			switch (switchVar) {
			case 'S':
				resultList = new ArrayList<String>(segmentList);
				break;

			case 'Q':
				
				//Getting data elements separated by field delimiter
				for (int i = 0; i < segmentList.size(); i++) {
					segmentString = (String) segmentList.get(i);
					List<String> tempFieldList = tokenize(segmentString,delimiterField);
					fieldList.addAll(tempFieldList);
				}
				
				//Getting list of field values				
				fieldNextValueList = getNextValueList(fieldList, fieldQualifier);
				resultList = new ArrayList<String>(fieldNextValueList);				
				
				//Getting list of sub field values based on sub field position
				if (subfieldPosition != null && !"".equals(subfieldPosition)) { 
					int subposAsInt=Integer.parseInt(subfieldPosition);
					
						for (int i = 0; i < resultList.size(); i++) {
							subFieldValue = (String) resultList.get(i);
							List<String> tempSubFieldList = tokenize(subFieldValue, delimiterSubField);
							if ((subposAsInt >= 1) && (subposAsInt <= tempSubFieldList.size())) {
							subFieldNextValueList.add(tempSubFieldList.get(subposAsInt - 1));
							}
						}
						resultList = new ArrayList<String>(subFieldNextValueList);
										
				} else if (subfieldQualifier != null && !"".equals(subfieldQualifier)) { 
				//Getting list of sub field values based on sub field qualifier
					for (int i = 0; i < resultList.size(); i++) {
						subFieldValue = (String) resultList.get(i);
						List<String> tempSubFieldList = tokenize(subFieldValue, delimiterSubField);
						subFieldList.addAll(tempSubFieldList);
					}
					subFieldNextValueList = getNextValueList(subFieldList,subfieldQualifier);
					resultList = new ArrayList<String>(subFieldNextValueList);
				}
				break;

			case 'P':
				//Getting data elements based on field position
				int posAsInt=Integer.parseInt(fieldPosition);
				for (int i = 0; i < segmentList.size(); i++) {
					segmentString = (String) segmentList.get(i);
					List<String> tempFieldList = tokenize(segmentString,delimiterField);
					if ((posAsInt >= 1) && (posAsInt <= tempFieldList.size())) {
					fieldNextValueList.add(tempFieldList.get(posAsInt - 1));
					}
				}
				resultList = new ArrayList<String>(fieldNextValueList);

				//Getting list of sub field values based on sub field position
				if (subfieldPosition != null && !"".equals(subfieldPosition)) { 
					int subposAsInt=Integer.parseInt(subfieldPosition);
					
					for (int i = 0; i < resultList.size(); i++) {
						subFieldValue = (String) resultList.get(i);
						List<String> tempSubFieldList = tokenize(subFieldValue, delimiterSubField);
						if ((subposAsInt >= 1) && (subposAsInt <= tempSubFieldList.size())) {
							subFieldNextValueList.add(tempSubFieldList.get(subposAsInt - 1));
						}
					}
					resultList = new ArrayList<String>(subFieldNextValueList);
					
				} else if (subfieldQualifier != null
						&& !"".equals(subfieldQualifier)) {
				//Getting list of sub field values based on sub field qualifier
					for (int i = 0; i < resultList.size(); i++) {
						subFieldValue = (String) resultList.get(i);
						List<String> tempSubFieldList = tokenize(subFieldValue, delimiterSubField);
						subFieldList.addAll(tempSubFieldList);
					}
					subFieldNextValueList = getNextValueList(subFieldList,subfieldQualifier);
					resultList = new ArrayList<String>(subFieldNextValueList);
				}
				break;

			default:
				errorMessage = "Either fieldQualifier or fieldPosition need to be provided";
				success = "1";
				break;
			}

		} catch (Exception e) {
			success = "1";
			errorMessage = "Exception occurred :" + e.getMessage();			
		}

		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "success", success);
		IDataUtil.put( pipelineCursor_1, "errorMessage", errorMessage);
		
		
		if (resultList.size()>=1){
			result = new String[resultList.size()];
		}
		
		if (resultList != null && resultList.size()>0){
			IDataUtil.put( pipelineCursor_1, "result", resultList.toArray(result));
			IDataUtil.put( pipelineCursor_1, "resultCount", String.valueOf(resultList.size()));
		} else {
			IDataUtil.put( pipelineCursor_1, "result", null);
			IDataUtil.put( pipelineCursor_1, "resultCount", "0");
		}

		//Comment below after testing
		String[] result1 = null;
		if (segmentList.size()>=1){
			result1 = new String[segmentList.size()];
		}
		if (segmentList != null && segmentList.size()>0) {
			IDataUtil.put( pipelineCursor_1, "result1", segmentList.toArray(result1));
		} else {			
			IDataUtil.put( pipelineCursor_1, "result1", null);
		}

		//comment end
		
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void extractDataFromFixedLenRecFile (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(extractDataFromFixedLenRecFile)>> ---
		// @sigtype java 3.5
		// [i] field:0:required fixedLengthContent
		// [i] field:0:required recordIdStartIndex
		// [i] field:0:required recordIdValue
		// [i] field:0:required fieldStartIndex
		// [i] field:0:required fieldEndIndex
		// [i] field:0:required fieldLength
		// [o] field:1:required fieldValueList
		// [o] field:0:required message
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		String	fixedLengthContent = IDataUtil.getString( pipelineCursor, "fixedLengthContent" );
		String	recordIdStartIndex = IDataUtil.getString( pipelineCursor, "recordIdStartIndex" );
		String	recordIdValue = IDataUtil.getString( pipelineCursor, "recordIdValue" );
		String	fieldStartIndex = IDataUtil.getString( pipelineCursor, "fieldStartIndex" );
		String	fieldEndIndex = IDataUtil.getString( pipelineCursor, "fieldEndIndex" );
		String	fieldLength = IDataUtil.getString( pipelineCursor, "fieldLength" );
		
		int iRecordIdStartIndex = 0;
		int recordIdValueLength = 0;
		int iRecordIdEndIndex = 0;
		int iFieldEndIndex = 0;
		int iFieldStartIndex = 0;
		String[] fieldValueList = null;
		String message = null;
		
		try{
		iRecordIdStartIndex = Integer.parseInt(recordIdStartIndex);
		recordIdValueLength = recordIdValue.length();
		iRecordIdEndIndex = iRecordIdStartIndex+recordIdValueLength;
		iFieldStartIndex = Integer.parseInt(fieldStartIndex);
		
		if(fieldEndIndex !=null && !"".equals(fieldEndIndex)){
			iFieldEndIndex = Integer.parseInt(fieldEndIndex)+1;
		}
		if(fieldLength !=null && !"".equals(fieldLength)){
			iFieldEndIndex = iFieldStartIndex+Integer.parseInt(fieldLength);
		}		
		
		pipelineCursor.destroy();
		StringTokenizer lineTokenizer = new StringTokenizer(fixedLengthContent, System.getProperty("line.separator"));
		List<String> valueList = new ArrayList<String>();
		while (lineTokenizer.hasMoreElements()) {	
			String line = (String)lineTokenizer.nextElement();			
			if (recordIdValue.equals(line.substring(iRecordIdStartIndex, iRecordIdEndIndex))){
				String value = line.substring(iFieldStartIndex, iFieldEndIndex);
				valueList.add(value);				
			}			
		}
		fieldValueList = (String[])valueList.toArray(new String[valueList.size()]);
		message = "SUCCESS";
		}catch(Exception e){
			message = "ERROR \n"+e.getMessage();
			/*StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			message = sw.toString();*/
		}
		
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		
		IDataUtil.put( pipelineCursor_1, "fieldValueList", fieldValueList );
		IDataUtil.put( pipelineCursor_1, "message", message );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void generateCSVExcel (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(generateCSVExcel)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] record:1:required records
		// [i] field:0:optional replaceCharForComma {";"}
		// [o] field:0:required csvContent
		
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		
			// results
			IData[]	records = IDataUtil.getIDataArray( pipelineCursor, "records" );
			
		        String replaceCharForComma = IDataUtil.getString( pipelineCursor, "replaceCharForComma" );
			if (replaceCharForComma==null) {replaceCharForComma=";";};
		        //String message = IDataUtil.getString( pipelineCursor, "message" );
			StringBuffer csvContent= new StringBuffer();
		
			if ( records != null)
			{			
						IDataCursor recordsCursor0 = records[0].getCursor();                                
		                               
						while (recordsCursor0.hasMoreData())
						{
		                                recordsCursor0.next();
						String thisVal=(String) recordsCursor0.getKey();
						csvContent.append(thisVal).append(",");
						}
		                                csvContent.append(System.getProperty("line.separator"));
		
					for ( int i = 0; i < records.length; i++ )
					{
						IDataCursor recordsCursor = records[i].getCursor();                                
		                               
						while (recordsCursor.hasMoreData())
						{
		                                recordsCursor.next();
						String thisVal=(String) recordsCursor.getValue();
						if (thisVal==null)
						{
							thisVal="";
						}
						thisVal=thisVal.replace(System.getProperty("line.separator"),"");
						thisVal=thisVal.replace("\n","");
						thisVal=thisVal.replace("\r","");
						thisVal=thisVal.replace(",",replaceCharForComma);
						csvContent.append(thisVal).append(",");
						}
		                csvContent.append(System.getProperty("line.separator"));
					}			
				
			}
		pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "csvContent", csvContent.toString());
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void generateHtmlTable (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(generateHtmlTable)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] record:1:required records
		// [i] field:0:optional hasCustomHeaders {"N","Y"}
		// [i] field:1:optional headers
		// [i] field:0:optional message
		// [i] field:0:optional tableName
		// [i] field:0:optional tableWidth {"100%","none"}
		// [i] field:0:optional leftIndent
		// [i] field:0:optional skipTop {"N","Y"}
		// [i] field:0:optional skipBottom {"N","Y"}
		// [i] field:0:optional skipExportButton {"N","Y"}
		// [i] field:0:optional skipFormViewButton {"N","Y"}
		// [i] record:0:optional color
		// [i] - record:0:optional background
		// [i] -- field:0:optional tr
		// [i] -- field:0:optional th
		// [i] -- field:0:optional tr_hover
		// [i] field:0:optional tpcodeColIndx
		// [i] field:0:optional dbToggleVar
		// [i] field:0:optional envID
		// [i] field:0:optional helpPageRef
		// [o] field:0:required htmlContent
		// pipeline 
		IDataCursor pipelineCursor = pipeline.getCursor();
		
			// results
			IData[]	records = IDataUtil.getIDataArray( pipelineCursor, "records" );
			String[] headers = IDataUtil.getStringArray( pipelineCursor, "headers" );
		        String message = IDataUtil.getString( pipelineCursor, "message" );
			String	skipTop = IDataUtil.getString( pipelineCursor, "skipTop" );
			String	skipBottom = IDataUtil.getString( pipelineCursor, "skipBottom" );
			String	hasCustomHeaders = IDataUtil.getString( pipelineCursor, "hasCustomHeaders" );
			String	skipExportButton = IDataUtil.getString( pipelineCursor, "skipExportButton" );
			String	skipFormViewButton = IDataUtil.getString( pipelineCursor, "skipFormViewButton" );
			String	tpcodeColIndx = IDataUtil.getString( pipelineCursor, "tpcodeColIndx" );
			String	dbToggleVar = IDataUtil.getString( pipelineCursor, "dbToggleVar" );
			if (dbToggleVar==null) {dbToggleVar="OLD";};
			String	envID = IDataUtil.getString( pipelineCursor, "envID" );
			if (envID==null) {envID="BETA";};
			String	leftIndent = IDataUtil.getString( pipelineCursor, "leftIndent" );
			if (leftIndent==null) {leftIndent="0px";}
			String	tableWidth = IDataUtil.getString( pipelineCursor, "tableWidth" );
			if (tableWidth==null) {tableWidth="100%";}
			String	tableName = IDataUtil.getString( pipelineCursor, "tableName" );
			if (tableName==null) {
				tableName="thisTable";
			}
			String	helpPageRef = IDataUtil.getString( pipelineCursor, "helpPageRef" );
			//if (helpPageRef==null) {helpPageRef="help.html#help.notavailable";};
		
			// color
			String	tr_bk_color = "#d4e3e5";
			String	th_bk_color = "#acc8cc";
			String	tr_hover_bk_color = "#ffffff";
		
			IData	color = IDataUtil.getIData( pipelineCursor, "color" );
			if ( color != null)
			{
				IDataCursor colorCursor = color.getCursor();
		
					// i_1.background
					IData	background = IDataUtil.getIData( colorCursor, "background" );
					if ( background != null)
					{
						IDataCursor backgroundCursor = background.getCursor();
							tr_bk_color = IDataUtil.getString( backgroundCursor, "tr" );
							th_bk_color = IDataUtil.getString( backgroundCursor, "th" );
							tr_hover_bk_color = IDataUtil.getString( backgroundCursor, "tr_hover" );
						backgroundCursor.destroy();
					}
				colorCursor.destroy();
			}
		
		
			StringBuffer htmlContent= new StringBuffer();
			String newline = System.getProperty("line.separator");
			String tpcode = null;
		
		
				if (skipTop==null || !skipTop.equals("Y"))
				{
				htmlContent.append("<HTML>").append(newline);
				htmlContent.append("<head>").append(newline);
				htmlContent.append("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">");
				htmlContent.append("<style type=\"text/css\">").append(newline);
		
				htmlContent.append(".tftable {font-size:12px;color:#333333;width:" + tableWidth + ";border-width: 1px;border-color: #729ea5;border-collapse: collapse;}").append(newline);
				htmlContent.append(".tftable th {font-size:12px;background-color:" + th_bk_color + ";border-width: 1px;padding: 8px;border-style: solid;border-color: #729ea5;text-align:left;}").append(newline);
				htmlContent.append(".tftable tr {background-color:" + tr_bk_color + ";}").append(newline);
				htmlContent.append(".tftable td {font-size:12px;border-width: 1px;padding: 8px;border-style: solid;border-color: #729ea5;}").append(newline);
				htmlContent.append(".tftable tr:hover {background-color:" + tr_hover_bk_color + ";}").append(newline);
				htmlContent.append("</style>").append(newline);
		
				htmlContent.append("<script src='../MiscToolbox/js/sorttable.js'></script>").append(newline);
				htmlContent.append("<script src='../MiscToolbox/js/tableToExcel.js'></script>").append(newline);
				htmlContent.append("<script src='../MiscToolbox/js/MiscToolbox.js'></script>").append(newline);
		
				htmlContent.append("</head>").append(newline);
		                htmlContent.append("<body>").append(newline);
		
				htmlContent.append("<a id='dlink'  style='display:none;'></a>");
				}
		
				htmlContent.append("<Table width=\"100%\" border='0' id='toptable1' name='toptable1'>").append(newline);
				htmlContent.append("<TR>").append(newline);
				
				if (message != null && !message.equals(""))
				{
		                	//htmlContent.append("<p style='padding-left:" + leftIndent + "'>").append(newline);
		                	htmlContent.append("<TD align=\"left\">").append(message).append("</TD>").append(newline);
				}
				if (helpPageRef !=null) { 
					htmlContent.append("<TD align=\"right\"><a href=\"..\\MiscToolbox\\").append(helpPageRef).append("\"><img src=\"../MiscToolbox/img/info.png\" width=\"20\" height=\"20\" /></a></TD>").append(newline);
					}
				htmlContent.append("</TR>").append(newline);
		
				htmlContent.append("<TR>").append(newline);
				if (skipExportButton == null || skipExportButton.equals("N"))
				{
		                	htmlContent.append("<TD align=\"left\">").append("<input type='button' onclick=\"tableToExcel('" + tableName + "', 'exportWorksheet', 'exportTable.xls')\" value='Export to Excel'>").append("</TD>").append(newline);
				}
				htmlContent.append("<TD align=\"right\">").append("<input type=\"button\" id=\"show_all" + tableName + "\" style=\"display:none;\" onclick=\"showallhidden('"+tableName+"')\" value=\"Show All Hidden\"></TD>").append(newline);
				htmlContent.append("</TR>").append(newline);
		
				htmlContent.append("</Table>").append(newline);
		
				htmlContent.append("<input type=\"hidden\" name=\"hide_class\" id =\"hide_class\" value=\"\" />").append(newline);
		
		
				htmlContent.append("<Table class=\"tftable sortable\" style='margin-left:" + leftIndent + "' border='1' id='" + tableName + "' name='" + tableName + "'>").append(newline);
				htmlContent.append("<TR id=\"table_header" + tableName + "\">").append(newline); //this id to be set to table_header else formview will not work
		
		
			if ( records == null || records.length == 0)
				{
					htmlContent.append("<TD>No Records</TD>");
				} else
				{		
		
					
					
					int colOffset;
					if (skipFormViewButton == null || skipFormViewButton.equals("N"))
					{
						//colOffset=1;
						htmlContent.append("<TH></TH>").append(newline);
					} else
					{
						//colOffset=0;
						
					}
		
					if (hasCustomHeaders == null || !hasCustomHeaders.equals("Y"))
					{
					IDataCursor recordsCursor0 = records[0].getCursor();                                
		                int i=0;
						while (recordsCursor0.hasMoreData())
						{
						i=i+1;
		                                recordsCursor0.next();
						String thisVal=(String) recordsCursor0.getKey();
						//htmlContent.append("<TH>").append(thisVal).append("</TH>");
						htmlContent.append("<TH class=\"class" + i + tableName + "\" ondblclick=\"javascript:hidecloumn('class" + i + tableName + "','"+ tableName +"');\">").append(thisVal).append("</TH>");
						htmlContent.append(newline);
						}
		
					}else  //have custom header
					{
		
						for ( int i = 0; i < headers.length; i++ )
						{
						String thisVal=(String) headers[i];
						htmlContent.append("<TH class=\"class" + (i + 1)+ tableName + "\" ondblclick=\"javascript:hidecloumn('class" + (i + 1) + tableName + "','"+ tableName +"');\">").append(thisVal).append("</TH>");
						htmlContent.append(newline);
						}
					}						
					htmlContent.append("</TR>");	
					htmlContent.append(newline);
		                        
		                        
					for ( int i = 0; i < records.length; i++ )  //for each record
					{
						IDataCursor recordsCursor = records[i].getCursor();
		                                
		                htmlContent.append("<TR id=\"row" + (i+1) + tableName + "\">").append(newline);
		                if (skipFormViewButton == null || skipFormViewButton.equals("N"))
						{
		                	htmlContent.append("<TD>").append("<input type=\"button\" name=\"FormView\" value=\"FormView\" onclick=\"javascript:popupFormView('table_header" + tableName + "','row" + (i+1) + tableName + "');\" />").append("</TD>").append(newline);
						}
		
						int j=0;
						while (recordsCursor.hasMoreData())	//for each column
						{
		                    recordsCursor.next();
							String thisVal=""; 
							if (recordsCursor.getValue()==null)
							{
								thisVal="";
							}
							else
							{
								//thisVal=(String) recordsCursor.getValue();
								//========handle data types=============================
								//String[]	inList = IDataUtil.getStringArray( recordsCursor, recordsCursor.getKey() );
								Object _obj = IDataUtil.get( recordsCursor, recordsCursor.getKey() );
								
								if(_obj instanceof java.lang.String)    
								{
									thisVal=(String) recordsCursor.getValue();
								}
		                        else if(_obj instanceof String[])          
								{       
		                        	String[]	atList = IDataUtil.getStringArray( recordsCursor, recordsCursor.getKey() );
		                        	if (atList.length == 1)
		                        	{
		                        		thisVal=(String) atList[0];
		                        	}
		                        	else { 
		                        		thisVal = thisVal + "<select style='background: transparent;'>";
		                        		for (int k=0;k < atList.length; k++)
		                        		{
		                        			thisVal = thisVal + "<option value=\"" + atList[k] + "\">" + atList[k] + "</option>";
		                        		}
		                        		thisVal = thisVal + "</select>";
		                        	}
		                        	//thisVal = recordsCursor.getKey()
							     }
								//=====================================
								if ((tpcodeColIndx != null) && (tpcodeColIndx.equals(String.valueOf(j)))) {
									tpcode=thisVal;
									thisVal="<a href=\"/invoke/MiscToolbox.services:provide_svcname?dbToggleVar=" + dbToggleVar + "&envID=" + envID + "&tpcode=" + tpcode + "\"  target=\"_blank\" >" + tpcode + "</a>";
								};
							}
							j=j+1;
							
							
							
							htmlContent.append("<TD class=\"class" + j + tableName + "\">").append(thisVal).append("</TD>");
							htmlContent.append(newline);
						}
			}
		                                htmlContent.append("</TR>");
						htmlContent.append(newline);
					}
								
				htmlContent.append("</Table>");
				htmlContent.append(newline);
		
			        
			
				if (skipBottom == null || !skipBottom.equals("Y"))
				{
				htmlContent.append("<br><br><br><br><br><br><br><br>");
				htmlContent.append(newline);
				htmlContent.append("</body></html>");
				}
			
		pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "htmlContent", htmlContent.toString());
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void getDateByDays (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getDateByDays)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required noOfDays
		// [i] field:0:required datePattern
		// [o] field:0:required date
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	noOfDays = IDataUtil.getString( pipelineCursor, "noOfDays" );
			String	datePattern = IDataUtil.getString( pipelineCursor, "datePattern" );
			int n = Integer.parseInt(noOfDays);
			DateFormat df = new SimpleDateFormat(datePattern);
			pipelineCursor.destroy();
		
		        Calendar cal1 = Calendar.getInstance();
		        cal1.add(Calendar.DATE, n);
		        String st = df.format(cal1.getTime());
		
		IDataCursor pipelineCursor1 = pipeline.getCursor();        
		IDataUtil.put( pipelineCursor1, "date", st);
		pipelineCursor1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getDependency (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getDependency)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required serviceNSname
		// [i] field:0:required include {"dependent","referenced","both"}
		// [o] record:0:required dependent
		// [o] record:0:required referenced
		IDataCursor pipelineCursor = pipeline.getCursor(); 
		String	serviceNSname = IDataUtil.getString( pipelineCursor, "serviceNSname" ); 
		String	includeVar = IDataUtil.getString( pipelineCursor, "include" ); 
		pipelineCursor.destroy(); 
		//IData dependentObj=null;
		
		NSNode nsNodeObj = Namespace.current().getNode(serviceNSname);	
		DependencyManager dm = NSDependencyManager.current();
		
		if (includeVar.equals("dependent") || includeVar.equals("both"))
		{ 
			IDataUtil.put( pipelineCursor, "dependent",dm.getDependent(nsNodeObj, null)); 
		}
		if (includeVar.equals("referenced") || includeVar.equals("both"))
		{ 
			IDataUtil.put( pipelineCursor, "referenced",dm.getReferenced(nsNodeObj, null)); 
		}
		
		pipelineCursor.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getEpochTime (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getEpochTime)>> ---
		// @sigtype java 3.5
		// [i] field:0:required dateTime
		// [i] field:0:required pattern
		// [o] field:0:required dateTimeInMillis
		IDataCursor pipelineCursor = pipeline.getCursor();
		String	dateTime = IDataUtil.getString( pipelineCursor, "dateTime" );
		String	pattern = IDataUtil.getString( pipelineCursor, "pattern" );		
		pipelineCursor.destroy();
		java.util.Date date = null;
		
		try{
			date = new SimpleDateFormat(pattern).parse(dateTime); 		 
		}catch(Exception e){			
		}
		long time = date.getTime()/1000;
		 
		String dateTimeInMillis = String.valueOf(time);
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "dateTimeInMillis", dateTimeInMillis );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getFlowFilePath (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getFlowFilePath)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required svcName
		// [o] field:0:required flowPath
		
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	inStr = IDataUtil.getString( pipelineCursor, "svcName" );
		pipelineCursor.destroy();
		
		String packageName = null;
		String remainingInStr = null;
		//String pathSeparator = System.getProperty("path.separator");
		String pathSeparator = "/";
		String outStr = null;
		
		if(inStr != null && inStr.indexOf(pathSeparator)!=-1){
			packageName = inStr.substring(0,inStr.indexOf(pathSeparator));
			remainingInStr = inStr.substring(inStr.indexOf(pathSeparator),inStr.length());
			remainingInStr = remainingInStr.replace(":",".").replace(".",pathSeparator);
			outStr = "packages"+pathSeparator+packageName+pathSeparator+"ns"+remainingInStr+pathSeparator+"flow.xml";
		}
		
		
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "flowPath", outStr );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getHostDetails (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getHostDetails)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [o] field:0:required hostname
		// [o] field:0:required user
		InvokeState is = InvokeState.getCurrentState();
		User user = is.getCurrentUser();
		String strUsername = user.getName();
		
		IDataCursor pipelineCursor = pipeline.getCursor();
		IDataUtil.put( pipelineCursor, "hostname", com.wm.app.b2b.server.ServerAPI.getServerName());
		IDataUtil.put( pipelineCursor, "user", strUsername );
		pipelineCursor.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getPackageSize (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getPackageSize)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required packageName
		// [o] field:0:required sizeInMB
		// [o] field:0:required sizeInByte
		// [o] field:0:required packageAbsolutePath
		// [o] field:0:required success
		// [o] field:0:required errorMessage
		IDataCursor pipelineCursor = pipeline.getCursor();
		String	packageName = IDataUtil.getString( pipelineCursor, "packageName" );
		pipelineCursor.destroy();
		File file = null;
		long size=0l;
		String code = null;
		String message = null;
		String curDir = System.getProperty("WM_HOME");
		String fileSeparator = System.getProperty("file.separator");	
		String baseDir = new StringBuffer().append(curDir).append(fileSeparator).toString();
		if (baseDir.endsWith("../"))
		{
			int indx = baseDir.indexOf("../");
			baseDir = baseDir.substring(0,indx);
		}
		
		String packagePath = baseDir+"packages"+fileSeparator+packageName;
		try{
		file = new File(packagePath);
		size = getFolderSize(file);
		code = "1";
		message = "Package found";
		}catch(Exception e){
		code = "0";
		message = "Package not found";
		}
		double sizeInMB = size/(double)(1024*1024);
		IDataCursor pipelineCursor1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor1, "sizeInMB",String.format("%.2f", sizeInMB));
		IDataUtil.put( pipelineCursor1, "sizeInByte",String.valueOf(size));
		IDataUtil.put( pipelineCursor1, "packageAbsolutepath", packagePath);
		IDataUtil.put( pipelineCursor1, "success", code);
		IDataUtil.put( pipelineCursor1, "errorMessage", message);
		pipelineCursor1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getStartEndDates (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getStartEndDates)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required datePattern
		// [o] field:0:required today
		// [o] field:0:required yesterday
		// [o] field:0:required tomorrow
		// [o] field:0:required curWkStartDate
		// [o] field:0:required curWkEndDate
		// [o] field:0:required curMonthStartDate
		// [o] field:0:required curMonthEndDate
		// [o] field:0:required curYearStartDate
		// [o] field:0:required curYearEndDate
		// [o] field:0:required prevYearCurWkStartDate
		// [o] field:0:required prevYearCurWkEndDate
		// [o] field:0:required prevYearCurMonthStartDate
		// [o] field:0:required prevYearCurMonthEndDate
		// [o] field:0:required prevYearStartDate
		// [o] field:0:required prevYearEndDate
		// [o] field:0:required nextYearCurWkStartDate
		// [o] field:0:required nextYearCurWkEndDate
		// [o] field:0:required nextYearCurMonthStartDate
		// [o] field:0:required nextYearCurMonthEndDate
		// [o] field:0:required nextYearStartDate
		// [o] field:0:required nextYearEndDate
		// [o] field:0:required prevWkStartDate
		// [o] field:0:required prevWkEndDate
		// [o] field:0:required prevMonthStartDate
		// [o] field:0:required prevMonthEndDate
		
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		String	datePattern = IDataUtil.getString( pipelineCursor, "datePattern" );
		pipelineCursor.destroy();
		
		/* Actual Implementation Start */
		
		String today = null;
		String yesterday = null;
		String tomorrow = null;
		
		String curWkStartDate = null;
		String curWkEndDate = null;
		String curMonthStartDate = null;
		String curMonthEndDate = null;
		String curYearStartDate = null;
		String curYearEndDate = null;
				
		String prevYearCurWkStartDate = null;
		String prevYearCurWkEndDate = null;
		String prevYearCurMonthStartDate = null;
		String prevYearCurMonthEndDate = null;
		String prevYearStartDate = null;
		String prevYearEndDate = null;
				
		String nextYearCurWkStartDate = null;
		String nextYearCurWkEndDate = null;
		String nextYearCurMonthStartDate = null;
		String nextYearCurMonthEndDate = null;
		String nextYearStartDate = null;
		String nextYearEndDate = null;
						
		String prevWkStartDate = null;
		String prevWkEndDate = null;
		String prevMonthStartDate = null;
		String prevMonthEndDate = null;
		
						
		try{
				
			DateFormat df = new SimpleDateFormat(datePattern);
			Calendar cal = Calendar.getInstance();
			int year = cal.get(Calendar.YEAR);
				
			/* Current Year */
		
			Calendar todayCal = (Calendar) cal.clone();
			todayCal.set(Calendar.HOUR_OF_DAY, 0);
			today = df.format(todayCal.getTime());
			
			Calendar yesterdayCal = (Calendar) todayCal.clone();
			yesterdayCal.add(Calendar.DAY_OF_YEAR, -1);
			yesterday = df.format(yesterdayCal.getTime());
		
			Calendar tomorrowCal = (Calendar) todayCal.clone();
			tomorrowCal.add(Calendar.DAY_OF_YEAR, 1);
			tomorrow = df.format(tomorrowCal.getTime());
				
			Calendar firsDayOfCurrentWeekCal = (Calendar) cal.clone();		
			firsDayOfCurrentWeekCal.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);        
			curWkStartDate = df.format(firsDayOfCurrentWeekCal.getTime());
		               
		        Calendar lastDayOfCurrentWeekCal = (Calendar) firsDayOfCurrentWeekCal.clone();
		        lastDayOfCurrentWeekCal.add(Calendar.DAY_OF_YEAR, 6);
		        curWkEndDate = df.format(lastDayOfCurrentWeekCal.getTime());
		                
		        Calendar firstDayOfCurrentMonthCal = (Calendar) cal.clone();
		        firstDayOfCurrentMonthCal.set(Calendar.DAY_OF_MONTH, 1);
		        curMonthStartDate = df.format(firstDayOfCurrentMonthCal.getTime());
		                
		        Calendar lastDayOfCurrentMonthCal = (Calendar) cal.clone();
		        lastDayOfCurrentMonthCal.set(Calendar.DATE, lastDayOfCurrentMonthCal.getActualMaximum(Calendar.DATE));
		        curMonthEndDate = df.format(lastDayOfCurrentMonthCal.getTime());
		                
		        Calendar firstDayOfCurrentYearCal = (Calendar) cal.clone();
		        firstDayOfCurrentYearCal.set(year,0,1);
		        curYearStartDate = df.format(firstDayOfCurrentYearCal.getTime());
		               
		        Calendar lastDayOfCurrentYearCal = (Calendar) cal.clone();
		        lastDayOfCurrentYearCal.set(year,11,31);
		        curYearEndDate = df.format(lastDayOfCurrentYearCal.getTime());
		                
		        /* Previous Year */
		        Calendar firsDayOfCurrentWeekPrevYearCal = (Calendar) firsDayOfCurrentWeekCal.clone();	
		        firsDayOfCurrentWeekPrevYearCal.set(Calendar.YEAR, year-1);
		        prevYearCurWkStartDate = df.format(firsDayOfCurrentWeekPrevYearCal.getTime());
		                
		        Calendar lastDayOfCurrentWeekPrevYearCal = (Calendar) lastDayOfCurrentWeekCal.clone();	
		        lastDayOfCurrentWeekPrevYearCal.set(Calendar.YEAR, year-1);
		        prevYearCurWkEndDate = df.format(lastDayOfCurrentWeekPrevYearCal.getTime());
		                
		        Calendar firstDayOfCurrentMonthPrevYearCal = (Calendar) firstDayOfCurrentMonthCal.clone();	
		        firstDayOfCurrentMonthPrevYearCal.set(Calendar.YEAR, year-1);
		        prevYearCurMonthStartDate = df.format(firstDayOfCurrentMonthPrevYearCal.getTime());
		             
		        Calendar lastDayOfCurrentMonthPrevYearCal = (Calendar) lastDayOfCurrentMonthCal.clone();	
		        lastDayOfCurrentMonthPrevYearCal.set(Calendar.YEAR, year-1);
		        prevYearCurMonthEndDate = df.format(lastDayOfCurrentMonthPrevYearCal.getTime());
		        
		        Calendar firstDayOfPrevYearCal = (Calendar) firstDayOfCurrentYearCal.clone();	
		        firstDayOfPrevYearCal.set(Calendar.YEAR, year-1);
		        prevYearStartDate = df.format(firstDayOfPrevYearCal.getTime());
		               
		        Calendar lastDayOfPrevYearCal = (Calendar) lastDayOfCurrentYearCal.clone();	
		        lastDayOfPrevYearCal.set(Calendar.YEAR, year-1);
		        prevYearEndDate = df.format(lastDayOfPrevYearCal.getTime());
		               
		        
		        /* Next Year */
		        
		        Calendar firsDayOfCurrentWeekNextYearCal = (Calendar) firsDayOfCurrentWeekCal.clone();	
		        firsDayOfCurrentWeekNextYearCal.set(Calendar.YEAR, year+1);
		        nextYearCurWkStartDate = df.format(firsDayOfCurrentWeekNextYearCal.getTime());
		                
		        Calendar lastDayOfCurrentWeekNextYearCal = (Calendar) lastDayOfCurrentWeekCal.clone();	
		        lastDayOfCurrentWeekNextYearCal.set(Calendar.YEAR, year+1);
		        nextYearCurWkEndDate = df.format(lastDayOfCurrentWeekNextYearCal.getTime());
		                
		        Calendar firstDayOfCurrentMonthNextYearCal = (Calendar) firstDayOfCurrentMonthCal.clone();	
		        firstDayOfCurrentMonthNextYearCal.set(Calendar.YEAR, year+1);
		        nextYearCurMonthStartDate = df.format(firstDayOfCurrentMonthNextYearCal.getTime());
		             
		        Calendar lastDayOfCurrentMonthNextYearCal = (Calendar) lastDayOfCurrentMonthCal.clone();	
		        lastDayOfCurrentMonthNextYearCal.set(Calendar.YEAR, year+1);
		        nextYearCurMonthEndDate = df.format(lastDayOfCurrentMonthNextYearCal.getTime());
		        
		        Calendar firstDayOfNextYearCal = (Calendar) firstDayOfCurrentYearCal.clone();	
		        firstDayOfNextYearCal.set(Calendar.YEAR, year+1);
		        nextYearStartDate = df.format(firstDayOfNextYearCal.getTime());
		               
		        Calendar lastDayOfNextYearCal = (Calendar) lastDayOfCurrentYearCal.clone();	
		        lastDayOfNextYearCal.set(Calendar.YEAR, year+1);
		        nextYearEndDate = df.format(lastDayOfNextYearCal.getTime());
		
		       /* Previous Week */
		        
		        Calendar firsDayOfPreviousWeekCurrentYearCal = (Calendar) firsDayOfCurrentWeekCal.clone();	
		        firsDayOfPreviousWeekCurrentYearCal.set(Calendar.DAY_OF_YEAR, firsDayOfPreviousWeekCurrentYearCal.get(Calendar.DAY_OF_YEAR)-7);
		        prevWkStartDate = df.format(firsDayOfPreviousWeekCurrentYearCal.getTime());
		        
		        Calendar lastDayOfPreviousWeekCal = (Calendar) lastDayOfCurrentWeekCal.clone();
		        lastDayOfPreviousWeekCal.set(Calendar.DAY_OF_YEAR,lastDayOfCurrentWeekCal.get(Calendar.DAY_OF_YEAR)-7);
		        prevWkEndDate = df.format(lastDayOfPreviousWeekCal.getTime());
		        
		        /* Previous Month */
		        
		        Calendar firstDayOfPrevMonthCal = (Calendar) firstDayOfCurrentMonthCal.clone();
		        firstDayOfPrevMonthCal.set(Calendar.MONTH, firstDayOfCurrentMonthCal.get(Calendar.MONTH)-1);
		        prevMonthStartDate = df.format(firstDayOfPrevMonthCal.getTime());
		         
		        Calendar lastDayOfPrevMonthCal = (Calendar) lastDayOfCurrentMonthCal.clone();
		        lastDayOfPrevMonthCal.set(Calendar.MONTH, lastDayOfCurrentMonthCal.get(Calendar.MONTH)-1);
		        prevMonthEndDate = df.format(lastDayOfPrevMonthCal.getTime());
		                
		}catch (Exception e){
			//System.out.println("Exception = "+e.getMessage());
		}
		
		/* Actual Implementation End */
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "today",today);
		IDataUtil.put( pipelineCursor_1, "yesterday",yesterday);
		IDataUtil.put( pipelineCursor_1, "tomorrow",tomorrow);
		
		IDataUtil.put( pipelineCursor_1, "curWkStartDate",curWkStartDate);
		IDataUtil.put( pipelineCursor_1, "curWkEndDate",curWkEndDate);
		IDataUtil.put( pipelineCursor_1, "curMonthStartDate",curMonthStartDate);
		IDataUtil.put( pipelineCursor_1, "curMonthEndDate",curMonthEndDate);
		IDataUtil.put( pipelineCursor_1, "curYearStartDate",curYearStartDate);
		IDataUtil.put( pipelineCursor_1, "curYearEndDate",curYearEndDate);
		
		IDataUtil.put( pipelineCursor_1, "prevYearCurWkStartDate",prevYearCurWkStartDate);
		IDataUtil.put( pipelineCursor_1, "prevYearCurWkEndDate",prevYearCurWkEndDate);
		IDataUtil.put( pipelineCursor_1, "prevYearCurMonthStartDate",prevYearCurMonthStartDate);
		IDataUtil.put( pipelineCursor_1, "prevYearCurMonthEndDate",prevYearCurMonthEndDate);
		IDataUtil.put( pipelineCursor_1, "prevYearStartDate",prevYearStartDate);
		IDataUtil.put( pipelineCursor_1, "prevYearEndDate",prevYearEndDate);
		
		IDataUtil.put( pipelineCursor_1, "nextYearCurWkStartDate",nextYearCurWkStartDate);
		IDataUtil.put( pipelineCursor_1, "nextYearCurWkEndDate",nextYearCurWkEndDate);
		IDataUtil.put( pipelineCursor_1, "nextYearCurMonthStartDate",nextYearCurMonthStartDate);
		IDataUtil.put( pipelineCursor_1, "nextYearCurMonthEndDate",nextYearCurMonthEndDate);
		IDataUtil.put( pipelineCursor_1, "nextYearStartDate",nextYearStartDate);
		IDataUtil.put( pipelineCursor_1, "nextYearEndDate",nextYearEndDate);
		
		IDataUtil.put( pipelineCursor_1, "prevWkStartDate",prevWkStartDate);
		IDataUtil.put( pipelineCursor_1, "prevWkEndDate",prevWkEndDate);
		IDataUtil.put( pipelineCursor_1, "prevMonthStartDate",prevMonthStartDate);
		IDataUtil.put( pipelineCursor_1, "prevMonthEndDate",prevMonthEndDate);
		
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getUser (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getUser)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [o] field:0:required user
		InvokeState is = InvokeState.getCurrentState();
		User user = is.getCurrentUser();
		String strUsername = user.getName();
		
		IDataCursor idc = pipeline.getCursor();
		IDataUtil.put( idc, "user", strUsername );
		idc.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void regexSearch (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(regexSearch)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required inputString
		// [i] field:0:optional regex
		// [o] field:1:required outputStringList
		// [o] field:0:required count
		
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	inputString = IDataUtil.getString( pipelineCursor, "inputString" );
			String	regex = IDataUtil.getString( pipelineCursor, "regex" );
		pipelineCursor.destroy();
		
		List<String> list = new ArrayList<String>();
		String count = "0";
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher=pattern.matcher(inputString);
		while (matcher.find()) {
		    list.add(matcher.group());
		}
		
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "outputStringList", list.toArray() );
		IDataUtil.put( pipelineCursor_1, "count", String.valueOf(list.size()) );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void removeNewline (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(removeNewline)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required inStr
		// [i] field:0:required newline
		// [o] field:0:required outStr
		
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	inStr = IDataUtil.getString( pipelineCursor, "inStr" );
			String	newline = IDataUtil.getString( pipelineCursor, "newline" );
		pipelineCursor.destroy();
		String outStr=null;
		if (inStr != null)
		{
		 outStr=inStr.replaceAll(newline,"");
		}
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "outStr", outStr );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void removeTokenWithinDelimiter (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(removeTokenWithinDelimiter)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required inStr
		// [i] field:0:required delimiter
		// [o] field:0:required outStr
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();	
		String	inStr = IDataUtil.getString( pipelineCursor, "inStr" );
		String	delimiter = IDataUtil.getString( pipelineCursor, "delimiter" );
		String[] tempStr = null;
		tempStr = inStr.split(delimiter);
		StringBuffer buf = new StringBuffer("");
		if(tempStr != null){
		for(int i=0;i<tempStr.length;i++){
			if(i%2 == 0) {
				buf.append(tempStr[i]);
			}
		}
		}							
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "outStr", buf.toString());
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void replaceDataInEDIX12String (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(replaceDataInEDIX12String)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:optional ediString
		// [i] field:0:required segmentName
		// [i] field:0:optional fieldQualifier
		// [i] field:0:optional subfieldQualifier
		// [i] field:0:optional fieldPosition
		// [i] field:0:optional subfieldPosition
		// [i] field:0:optional returnRecord
		// [i] field:0:required newVal
		// [o] field:0:required success
		// [o] field:0:optional errorMessage
		// [o] field:0:optional ediString
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		String	ediString = IDataUtil.getString( pipelineCursor, "ediString" );
		String	segmentName = IDataUtil.getString( pipelineCursor, "segmentName" );
		String	fieldQualifier = IDataUtil.getString( pipelineCursor, "fieldQualifier" );
		String	fieldPosition = IDataUtil.getString( pipelineCursor, "fieldPosition" );
		String	returnRecord = IDataUtil.getString( pipelineCursor, "returnRecord" );
		String	newValue = IDataUtil.getString( pipelineCursor, "newVal" );
		pipelineCursor.destroy();

		//Define Output variables
		String success = "0";
		String errorMessage = null;
		StringTokenizer segmentTokenizer = null;
		String segmentString = null;			
		String delimiterSegment = null;
		String delimiterField = null;
		String delimiterSubField = null;

		final String RETURNRECORD_FLAG = "Y";				
		StringBuffer EDIStringBuf = new StringBuffer("");
		
		//below positions are based on zero based indexing
		final int FIELDDELIMITER_POSITION_IN_ISASEGMENT=103;
		final int SUBFIELDDELIMITER_POSITION_IN_ISASEGMENT=104;
		final int SEGMENTDELIMITER_POSITION_IN_ISASEGMENT=105;
		final int ISASEGMENT_LENGTH=106;				
				
		delimiterField = String.valueOf(ediString.charAt(FIELDDELIMITER_POSITION_IN_ISASEGMENT));
		delimiterSubField = String.valueOf(ediString.charAt(SUBFIELDDELIMITER_POSITION_IN_ISASEGMENT));
		delimiterSegment = String.valueOf(ediString.charAt(SEGMENTDELIMITER_POSITION_IN_ISASEGMENT));		

		try {					
			char switchVar = ' ';
			if (returnRecord != null && RETURNRECORD_FLAG.equals(returnRecord)) 
			{
				switchVar = 'S'; // Full Segment
			} else if (fieldQualifier != null && !"".equals(fieldQualifier)) 
			{
				switchVar = 'Q'; // Qualifier based
			} else if (fieldPosition != null && !"".equals(fieldPosition)) 
			{ 
				switchVar = 'P'; // Field Position based
			}

			
			switch (switchVar) {
			case 'Q':
				segmentTokenizer = new StringTokenizer(ediString, delimiterSegment);
				while (segmentTokenizer.hasMoreElements()) {
					segmentString = segmentTokenizer.nextToken();
					if ((segmentString.contains(segmentName)) && (segmentString.contains(fieldQualifier))) {
						StringTokenizer fieldTokenizer = new StringTokenizer(segmentString, delimiterField);
						List<String> fieldList1= new ArrayList<String>();
						StringBuffer segmentBuf = new StringBuffer("");
						while (fieldTokenizer.hasMoreElements()) {
							String field = fieldTokenizer.nextToken();
							if(field.equals(fieldQualifier)){
								fieldList1.add(field);
								fieldList1.add(newValue);
								fieldTokenizer.nextToken();										
							}else{
								fieldList1.add(field);
							}									
						}
						for(int i=0;i<fieldList1.size();i++){
							if(i<fieldList1.size()-1){
								segmentBuf.append(fieldList1.get(i)).append(delimiterField);
							}else{
								segmentBuf.append(fieldList1.get(i));
							}									
						}
						EDIStringBuf.append(segmentBuf.toString()+delimiterSegment);
					}else{
						EDIStringBuf.append(segmentString+delimiterSegment);
					}					
				}
				break;

			case 'P':
				//Getting data elements based on field position
				int posAsInt=Integer.parseInt(fieldPosition);
				segmentTokenizer = new StringTokenizer(ediString, delimiterSegment);
				while (segmentTokenizer.hasMoreElements()) {
					segmentString = segmentTokenizer.nextToken();
					int fieldPosition1 = 0;
					if ((segmentString.contains(segmentName))) {
						StringTokenizer fieldTokenizer = new StringTokenizer(segmentString, delimiterField);
						List<String> fieldList1= new ArrayList<String>();
						StringBuffer segmentBuf = new StringBuffer("");
						while (fieldTokenizer.hasMoreElements()) {
							String field = fieldTokenizer.nextToken();
							fieldPosition1++;
							if(fieldPosition1 == posAsInt){
								fieldList1.add(field);
								fieldList1.add(newValue);
								fieldTokenizer.nextToken();
							}else{
								fieldList1.add(field);
							}									
						}
						for(int i=0;i<fieldList1.size();i++){
							if(i<fieldList1.size()-1){
								segmentBuf.append(fieldList1.get(i)).append(delimiterField);
							}else{
								segmentBuf.append(fieldList1.get(i));
							}									
						}
						EDIStringBuf.append(segmentBuf.toString()+delimiterSegment);
					}else{
						EDIStringBuf.append(segmentString+delimiterSegment);
					}
				}						
				break;

			default:
				errorMessage = "Either fieldQualifier or fieldPosition need to be provided";
				success = "1";
				break;
			}

		} catch (Exception e) {
			success = "1";
			errorMessage = "Exception occurred :" + e.getMessage();			
		}

		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "success", success);
		IDataUtil.put( pipelineCursor_1, "errorMessage", errorMessage);
		IDataUtil.put( pipelineCursor_1, "ediString", EDIStringBuf.toString());
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void throwException (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(throwException)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required message
		IDataCursor pipelineCursor = pipeline.getCursor();
		String	message = IDataUtil.getString( pipelineCursor, "message" );
		pipelineCursor.destroy();
		throw(new ServiceException(message));
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	
	public static String getValFromIData(IData idt, String valPath) throws ServiceException 
	{        
	        if ((idt == null) || (valPath == null) || (valPath.equals("")))     {      return "";        };     
	        //log2server(valPath);       
	        if (valPath.charAt(0) == '/')   {valPath = valPath.substring(1, valPath.length());};  //if first char is /, then skip that
	
	        String delim = "/";
	        String theToken = "";
	        Object _obj;
	        String[] thePathArray = valPath.split(delim);
	        int i = 0;
			//if (thePathArray.length <= 0) {return "";};
	
	        while (i < thePathArray.length)
	        {			
	                //log2server(" loop i = " + i);
					//if (theToken.equals("")) {return "";};
					theToken = thePathArray[i];
	                int sIndx = theToken.indexOf("[");
	                int eIndx = theToken.indexOf("]");
	
	                if ((sIndx != -1) && (eIndx != -1))        //doclist
	                {
							String docIndx=theToken.substring(sIndx+1,eIndx);
	                        String doclToken = theToken.substring(0,sIndx);
	                        _obj = IDataUtil.get(idt.getCursor(),doclToken);
							if (_obj == null) {return "";};
	                        IData[] idta = (IData[]) _obj;
							if (idta == null) {return "";};
							if (idta.length <= Integer.parseInt(docIndx)) {return "";};
	                        idt = idta[Integer.parseInt(docIndx)];
	                }
	                else
	                {
							_obj = IDataUtil.get(idt.getCursor(),theToken);
							if (_obj == null) {return "";};
	                        if(_obj instanceof java.lang.String)    
							{
								return (String) _obj;
							}
	                        else if(_obj instanceof IData)          
							{       
								idt = (IData) _obj;
						     }
							else if(_obj instanceof IData[])          
							{       
								//idt = (IData) _obj;
						     }						
	                }
	                i = i + 1;
	        }
	        return null;
	}
	
	
	public static void compareTwoIData(IData resultIData,IData firstIData,IData secondIData,String firstQualifier, String secondQualifier, String curPath) throws ServiceException 
	{ 
	        
	        String nextPath = "";
	        IDataCursor resultCursor = resultIData.getCursor();
	        //check null cases later        
	
	        while (resultCursor.hasMoreData())
	        {
					resultCursor.next();
	                
	                String _strKey = resultCursor.getKey() ;
	                Object _obj = IDataUtil.get(resultCursor,_strKey) ;
	
	                if(_obj instanceof java.lang.String)
	                {
							nextPath = curPath + "/" + _strKey;
	                        String v1 = getValFromIData(firstIData,nextPath); 
	                        String v2 = getValFromIData(secondIData,nextPath);
	
	                        if (!v1.equals(v2))
	                        {
								resultCursor.setValue("<PRE><font color='Red'>" + firstQualifier + v1 + "\n" + secondQualifier + v2 + "</font></PRE>");
	                        }	                   
	                }
	                else if(_obj instanceof IData)
	                {       
	                        nextPath = curPath + "/" + _strKey;
	                        IData tmpIdt = (IData) _obj;			
	                        compareTwoIData(tmpIdt,firstIData,secondIData,firstQualifier,secondQualifier,nextPath);
	                }
	                else if(_obj instanceof IData[])
	                {                                          
							String basePath = curPath + "/" + _strKey + "[";
	                        IData[] idta = (IData[]) _obj;
	                        for ( int i = 0; i < idta.length; i++ )
	                        {			
									nextPath = basePath + String.valueOf(i) + "]";
	                                compareTwoIData(idta[i],firstIData,secondIData,firstQualifier,secondQualifier,nextPath);                                
	                        }                        
	                }
	                else
	                {
	                        // do nothing
	                }                
	        } 
	        
	        return;        
	}
	public static void log2server(String msg)  throws ServiceException 
	{ 
	    //com.wm.util.JournalLogger.log(3,90,3,"LOG > " + msg );
		/*
		BufferedWriter fileWriter = null;
		try {
		fileWriter = new BufferedWriter( new FileWriter("/opt/softwareag/webMethods8/product/beta/ctgServer1/IntegrationServer/packages/zzTest123/debug.log", true) );
		fileWriter.write( msg + "\n" );
		fileWriter.close();
		} catch ( IOException e ) {
	    throw new ServiceException( e );} */
		
	
	}
	
	
	
		public static long getFolderSize(File dir) {
		    long size = 0;
		    for (File file : dir.listFiles()) {
		        if (file.isFile()) {
		            size += file.length();
		        }
		        else
		            size += getFolderSize(file);
		    }
		    return size;
		}
	
	static List tokenize(String datastring,String delimiter)
	{
	int curpos=0;
	int prevpos=0;
	long strlen=datastring.length();
	List<String> tokenList = new ArrayList<String>();
	String partStr="";
	curpos=0;
	prevpos=-1;
	boolean exitFlag=false;
	String[] tokens = null;
	do 
	{
		curpos=datastring.indexOf(delimiter,curpos+1);
		if (curpos == -1)
		{
			curpos=datastring.length();
			exitFlag=true;
		}
			
			partStr=datastring.substring(prevpos+1,curpos);
			if (!(partStr.equals("") && exitFlag))
				tokenList.add(partStr);
		
			prevpos=curpos;
	}
	while (!exitFlag);
	
	
	
	return tokenList;
	}
	
	static List getNextValueList(List inList,String searchStr)
	{
		List<String> outList = new ArrayList<String>();
	
		for (int j = 0; j < inList.size()-1; j++)
		{
			String tmp=(String)inList.get(j+1);
			if (searchStr.equals(inList.get(j)) && ((j+1) <inList.size())) 
			{
				outList.add(tmp);
			}
		}									
		return outList;
	}
	
	private static void disableSslVerification() {
	    try
	    {
	        // Create a trust manager that does not validate certificate chains
	        TrustManager[] trustAllCerts = new TrustManager[] {new X509TrustManager() {
	            public java.security.cert.X509Certificate[] getAcceptedIssuers() {
	                return null;
	            }
	            public void checkClientTrusted(X509Certificate[] certs, String authType) {
	            }
	            public void checkServerTrusted(X509Certificate[] certs, String authType) {
	            }
	        }
	        };
	
	        // Install the all-trusting trust manager
	        SSLContext sc = SSLContext.getInstance("SSL");
	        sc.init(null, trustAllCerts, new java.security.SecureRandom());
	        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
	
	        // Create all-trusting host name verifier
	        HostnameVerifier allHostsValid = new HostnameVerifier() {
	            public boolean verify(String hostname, SSLSession session) {
	                return true;
	            }
	        };
	
	        // Install the all-trusting host verifier
	        HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
	    } catch (NoSuchAlgorithmException e) {
	        e.printStackTrace();
	    } catch (KeyManagementException e) {
	        e.printStackTrace();
	    }
	}
	// --- <<IS-END-SHARED>> ---
}

